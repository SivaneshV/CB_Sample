from flask import Flask, render_template, request, session
import flask
from flask.templating import render_template_string
import db_proxy
import json
app = Flask(__name__)
app.secret_key = 'POC1'
login_users = []
Register_users=[]

@app.route('/home')
def home():
   return render_template('land.html')

@app.route('/profile')
def profile():
   return render_template('profilepage2.html') 
@app.route('/changepassword')
def changepassword():
   return render_template('changepwd.html') 
@app.route('/profile_edit')
def profile_edit():
   return render_template('profileedit.html') 
@app.route('/')
def login():
    return render_template('login.html')

@app.route('/register_click')
def register_click():
    return render_template('register1.html')

@app.route('/logon', methods=['POST'])
def logon():
    print(request.method)
    res = False
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        res = db_proxy.check_user(username, password)

        if res == True:
            login_users.append(username)
            session["username"] = username

    print('sdfasdfads', res)
    return json.dumps(res)


@app.route('/register', methods=['POST'])
def register():
    
    res = db_proxy.register()
    return json.dumps(res)

@app.route('/change_password', methods=['POST'])
def change_password():
    
    res = db_proxy.change_password()
    return json.dumps(res)

@app.route('/update_profile', methods=['POST'])
def update_profile():
    
    res = db_proxy.update_profile()
    return json.dumps(res)

@app.route('/fetch', methods=['GET'])
def fetch():
    
    res = db_proxy.fetch()
    return json.dumps(res)
@app.route('/logout', methods=['GET', 'POST'])
def logout():
    status = ""

    try:
        session["username"] = ''
        status = "updated"
    except:
        pass

    return status

app.run(port=4858)











