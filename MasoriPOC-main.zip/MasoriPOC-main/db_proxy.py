from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector
import re
import pandas as pd

conn = mysql.connector.connect(host="localhost",user="root",passwd="Devidevi1197$",port='3306',database="doctorfind")
cur=conn.cursor()

  
def register():
    cur=conn.cursor()

    print("data is saved")
    print(request.method)
    if request.method == 'POST':
        firstname = request.form['FirstName']
        print(firstname)
        lastname = request.form['LastName']
        email=request.form['Email']
        password=request.form['Password']
        contactnumber= request.form['ContactNumber']
        designation=request.form['Designation']
        street=request.form['Street']
        area=request.form['Area']
        city=request.form['City']
        state=request.form['State']
        country=request.form['Country']
        zipcode=request.form['Zipcode']
        cur.execute("insert into register_data (Firstname,Lastname,Password,ContactNumber,Email,Street,Area,City,State,Country,Zipcode,Designation) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(firstname,lastname,password,contactnumber,email,street,area,city,state,country,zipcode,designation))
        conn.commit()
        cur.close()
        print('done')
       
    #     val=firstname,lastname,password,contactnumber,email,street,area,city,state,country,zipcode,designation
    #     msg = 'Please fill out the form !'
    # elif not val:
       
    #     return render_template('register1.html', msg = msg)
    
    # cur.execute("Show tables;")
    # myresult = cur.fetchall()
 
    # for x in myresult:
    #     print(x)
    # sql="insert into register_data (Firstname,Lastname,Password,Confirmpassword,ContactNumber,Email,Street,Area,City,State,Country,Zipcode,Designation) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    # val=(firstname,lastname,password,confirmpassword,contactnumber,email,street,area,city,state,country,zipcode,designation)
    # cur.execute(sql,val)
    # cur.execute("SELECT * FROM doctorfind.register_data;")
   
    
def check_user(username,password):
    
    cur=conn.cursor()
    cur.execute("Select * from register_data Where Email='" + username+"' and Password='"+password+"' and Status='Active'")
    row = cur.fetchone() 
    while row:
        print(row[0])
        row = cur.fetchone()
    user = pd.read_sql_query("Select * from register_data Where Email='" +
                             username+"' and Password='"+password+"' and Status='Active'", conn)
    if user.empty:
        return False
    else:
        return True
    # if username.lower() == 'admin' and password == '123':
    #     return True
    # if username.lower() == 'masori' and password == '123':
    #     return True
def change_password():
    print(request.method)
    cur=conn.cursor()
    if request.method=="POST":
        currentpassword=request.form['currentpassword']
        newpassword=request.form['newpassword']
        cur.execute("Select * from register_data Where Password='" + currentpassword +"' and Status='Active'")
        row = cur.fetchone() 
        while row:
            print(row[0])
            row = cur.fetchone()
        user = pd.read_sql_query("Select * from register_data Where Password='" + currentpassword +"' and Status='Active'", conn)
        if user.empty:
            return False
        else:
            updatequery=("Update register_data SET Password= %s WHERE Password= %s")
            value=([newpassword,currentpassword])
            cur.execute(updatequery,value)
            conn.commit()
            cur.close()
            username = session["username"]
            print(username)
            return True
        
def update_profile():
    cur=conn.cursor()

    print("data is saved")
    print(request.method)
    if request.method == 'POST':
        username = session["username"]
        print(username)
        firstname = request.form['FirstName']
        print(firstname)
        lastname = request.form['LastName']
        email=request.form['Email']
        contactnumber= request.form['ContactNumber']
        designation=request.form['Designation']
        street=request.form['Street']
        area=request.form['Area']
        city=request.form['City']
        state=request.form['State']
        country=request.form['Country']
        zipcode=request.form['Zipcode']
        update=("Update register_data SET Firstname=%s,Lastname=%s,ContactNumber=%s,Email=%s,Street=%s,Area=%s,City=%s,State=%s,Country=%s,Zipcode=%s,Designation =%s where Email='"+username+"' and Status='Active'")
        value=([firstname,lastname,contactnumber,email,street,area,city,state,country,zipcode,designation])
        cur.execute(update,value)
        conn.commit()
        cur.close()
        print('done')
        # cur.execute("insert into register_data (Firstname,Lastname,Password,ContactNumber,Email,Street,Area,City,State,Country,Zipcode,Designation) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(firstname,lastname,password,contactnumber,email,street,area,city,state,country,zipcode,designation))

def fetch():
    print(request.method)
    if request.method == 'GET':
        username = session['username']
        print(username)
        # text1=("Select Firstname,Lastname,Password,ContactNumber,Email,Street,Area,City,State,Country,Zipcode,Designation FROM register_data Where ;")
        # cur.execute(text1)
        # row = cur.fetchone() 
        # while row:
        #     print(row[0])
        #     row = cur.fetchone()
        # # user = pd.read_sql_query("Select Firstname FROM register_data Where order by Id DESC limit 1;", conn)
        #     return row[0]
        
        cursor=conn.cursor()
        user_check="Select * from register_data Where Email='"+username+"' and Status='Active'"
        cursor.execute(user_check)
        value=cursor.fetchall()
        if len(value) > 0:
            new_list=[]
            for val in value:
                firstname=val[2]
                lastname=val[3]
                contactnumber=val[5]
                email=val[6]
                street=val[7]
                area=val[8]
                city=val[9]
                state=val[10]
                country=val[11]
                zipcode=val[12]
                designation=val[13]
              
                new_list.append(firstname )
                new_list.append(lastname )
                new_list.append(contactnumber)
                new_list.append(email )
                new_list.append(street)
                new_list.append(area)
                new_list.append(city)
                new_list.append(state)
                new_list.append(country)
                new_list.append(zipcode)
                new_list.append(designation)
            print(new_list)
            return new_list
            
                
         
               
                
       



               


